package com.example.youtube;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.android.material.badge.BadgeUtils;

public class MainActivity extends AppCompatActivity {

    private LinearLayout l1, l2, l3;
    private boolean start_stop = false;
    private Button button1;
    private int counter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l1 = (LinearLayout) findViewById(R.id.lamp1);
        l2 = (LinearLayout) findViewById(R.id.lamp2);
        l3 = (LinearLayout) findViewById(R.id.lamp3);
        button1 = (Button) findViewById(R.id.button);

    }
    public void onClickStart (View v) {
        if (!start_stop) {
            start_stop = true;
                button1.setText("STOP");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (start_stop) {
                        counter++;
                        switch (counter){
                            case 1:
                                l1.setBackgroundColor(getResources().getColor(R.color.Red));
                                l2.setBackgroundColor(getResources().getColor(R.color.Grey));
                                l3.setBackgroundColor(getResources().getColor(R.color.Grey));
                                break;
                            case 2:
                                l1.setBackgroundColor(getResources().getColor(R.color.Grey));
                                l2.setBackgroundColor(getResources().getColor(R.color.Yellow));
                                l3.setBackgroundColor(getResources().getColor(R.color.Grey));
                                break;
                            case 3:
                                l1.setBackgroundColor(getResources().getColor(R.color.Grey));
                                l2.setBackgroundColor(getResources().getColor(R.color.Grey));
                                l3.setBackgroundColor(getResources().getColor(R.color.Green));
                                counter = 0;
                                break;
                        }

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        } else {
            start_stop = false;
            button1.setText("START");
        }



    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        start_stop = false;
    }
}
